<?php
if (!defined('UAP_CORE')) die('What are you doing here?');
?>
					</div>
					<div id="message"></div>
				</div>
			</div>
		</div>
	</body>
</html>